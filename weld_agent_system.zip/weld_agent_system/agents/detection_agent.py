from ultralytics import YOLO


class DetectionAgent:

    def __init__(self, model_path):

        self.model = YOLO(model_path)

    def detect(self, image_path):

        results = self.model(image_path)

        detections = []

        for result in results:

            boxes = result.boxes

            for box in boxes:

                cls = int(box.cls[0])
                conf = float(box.conf[0])

                detections.append({
                    "class": cls,
                    "confidence": conf
                })

        return detections
