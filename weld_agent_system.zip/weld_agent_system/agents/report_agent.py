class ReportAgent:

    def generate(self, analysis_result, grade, save_path):

        report = f"""
=========================
焊点质量检测报告
=========================

缺陷数量：{analysis_result['defect_count']}
平均置信度：{analysis_result['avg_confidence']}
质量等级：{grade}

结论：
系统已完成焊点自动检测与质量评估。

=========================
"""

        with open(save_path, "w", encoding="utf-8") as f:
            f.write(report)

        return report
