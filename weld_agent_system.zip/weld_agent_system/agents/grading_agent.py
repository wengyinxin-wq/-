class GradingAgent:

    def grade(self, analysis_result):

        defect_count = analysis_result["defect_count"]
        confidence = analysis_result["avg_confidence"]

        if defect_count == 0:
            return "A级"

        elif defect_count <= 2 and confidence < 0.6:
            return "B级"

        else:
            return "C级"
