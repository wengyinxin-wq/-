class AnalysisAgent:

    def analyze(self, detections):

        defect_count = len(detections)

        avg_conf = 0

        if defect_count > 0:
            avg_conf = sum(d["confidence"] for d in detections) / defect_count

        result = {
            "defect_count": defect_count,
            "avg_confidence": round(avg_conf, 3)
        }

        return result
