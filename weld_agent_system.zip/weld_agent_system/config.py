MODEL_PATH = "models/best.pt"
IMAGE_PATH = "images/test.jpg"
REPORT_PATH = "outputs/report.txt"
