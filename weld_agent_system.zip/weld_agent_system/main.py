from config import *

from agents.preprocess_agent import PreprocessAgent
from agents.detection_agent import DetectionAgent
from agents.analysis_agent import AnalysisAgent
from agents.grading_agent import GradingAgent
from agents.report_agent import ReportAgent


def main():

    print("===== 焊点质量分析 Agent 系统启动 =====")

    preprocess_agent = PreprocessAgent()
    detection_agent = DetectionAgent(MODEL_PATH)
    analysis_agent = AnalysisAgent()
    grading_agent = GradingAgent()
    report_agent = ReportAgent()

    print("[1] 图像预处理")
    image, processed = preprocess_agent.process(IMAGE_PATH)

    print("[2] 缺陷检测")
    detections = detection_agent.detect(IMAGE_PATH)

    print("检测结果：")
    print(detections)

    print("[3] 缺陷分析")
    analysis_result = analysis_agent.analyze(detections)

    print(analysis_result)

    print("[4] 质量评级")
    grade = grading_agent.grade(analysis_result)

    print("质量等级：", grade)

    print("[5] 生成报告")
    report = report_agent.generate(
        analysis_result,
        grade,
        REPORT_PATH
    )

    print(report)

    print("===== 系统运行结束 =====")


if __name__ == "__main__":
    main()
