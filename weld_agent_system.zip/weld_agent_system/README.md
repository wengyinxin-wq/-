# Weld Quality Agent System

基于 YOLO 的焊点质量分析 Agent 系统。

## 功能

- 图像预处理
- 焊点缺陷检测
- 缺陷分析
- 自动评级
- 自动生成检测报告

## 安装

```bash
pip install -r requirements.txt
```

## 运行

```bash
python main.py
```
